package com.netcap.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.text.DecimalFormat

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("netcap", MODE_PRIVATE) }
    private lateinit var usage: TextView
    private lateinit var status: TextView
    private lateinit var quotaInput: EditText
    private lateinit var unit: Spinner
    private lateinit var autoCut: CheckBox
    private lateinit var warningInput: EditText

    private var pendingAction = ""
    private val vpnRequestCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        refresh()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }

        root.addView(TextView(this).apply {
            text = "NetCap"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(0xFF101828.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Your internet. Your limit. Your control."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF667085.toInt())
        })

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(8, 22, 8, 8)
        }
        usage = TextView(this).apply {
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 18)
            setTextColor(0xFF101828.toInt())
        }
        root.addView(status)
        root.addView(usage)

        root.addView(section("YOUR DATA LIMIT"))
        val quotaRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        quotaInput = EditText(this).apply {
            hint = "Enter amount"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getString("quotaValue", "20"))
            textSize = 18f
        }
        quotaRow.addView(quotaInput, LinearLayout.LayoutParams(0, -2, 1f))
        unit = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("MB", "GB"))
            setSelection(prefs.getInt("quotaUnit", 1).coerceIn(0, 1))
        }
        quotaRow.addView(unit, LinearLayout.LayoutParams(120, -2))
        root.addView(quotaRow)

        autoCut = CheckBox(this).apply {
            text = "Auto-block when my quota is reached"
            isChecked = prefs.getBoolean("auto", false)
            setTextColor(0xFF344054.toInt())
        }
        root.addView(autoCut)

        root.addView(section("WARNING THRESHOLD (%)"))
        warningInput = EditText(this).apply {
            hint = "80"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getString("warning", "80"))
        }
        root.addView(warningInput)

        addButton(root, "SAVE SETTINGS", 0xFF344054.toInt()) {
            if (saveSettings()) toast("Settings saved")
        }
        addButton(root, "START LIMIT / MONITOR", 0xFF16804A.toInt()) {
            if (saveSettings()) startMonitoring()
        }
        addButton(root, "STOP LIMIT / MONITOR", 0xFF667085.toInt()) {
            stopService(Intent(this, UsageMonitorService::class.java).setAction(UsageMonitorService.ACTION_STOP))
            prefs.edit().putBoolean(UsageMonitorService.KEY_MONITORING, false).apply()
            refresh()
        }
        addButton(root, "RESET USAGE COUNTER", 0xFF667085.toInt()) {
            prefs.edit().putLong(UsageMonitorService.KEY_USED, 0L).apply()
            refresh()
            toast("Usage counter reset")
        }
        addButton(root, "BLOCK INTERNET NOW", 0xFFD92D20.toInt()) {
            requestVpnPermissionThen("block")
        }
        addButton(root, "RESTORE INTERNET", 0xFFD81B60.toInt()) {
            stopService(Intent(this, BlockVpnService::class.java).setAction(BlockVpnService.ACTION_UNBLOCK))
            prefs.edit().putBoolean(BlockVpnService.KEY_BLOCKED, false).apply()
            refresh()
            toast("Internet restore requested")
        }

        root.addView(TextView(this).apply {
            text = "NetCap uses Android's local VPN firewall. It blocks routed IPv4 and IPv6 traffic; it does not physically switch off the Wi-Fi or mobile-data toggles. Usage is measured by Android system byte counters and may differ from carrier billing."
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(4, 18, 4, 4)
        })

        ScrollView(this).apply { addView(root) }.also { setContentView(it) }
    }

    private fun section(label: String) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(0xFF667085.toInt())
        setPadding(2, 18, 2, 4)
    }

    private fun addButton(root: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(-1)
            backgroundTintList = android.content.res.ColorStateList.valueOf(color)
            setOnClickListener { action() }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7 })
    }

    private fun saveSettings(): Boolean {
        val value = quotaInput.text.toString().toDoubleOrNull()
        if (value == null || value <= 0.0) {
            quotaInput.error = "Enter a limit greater than zero"
            return false
        }
        val warning = warningInput.text.toString().toIntOrNull() ?: 80
        if (warning !in 1..100) {
            warningInput.error = "Enter a percentage from 1 to 100"
            return false
        }
        val multiplier = if (unit.selectedItemPosition == 0) 1024.0 * 1024.0 else 1024.0 * 1024.0 * 1024.0
        val bytes = (value * multiplier).coerceAtMost(Long.MAX_VALUE.toDouble()).toLong()
        prefs.edit()
            .putString("quotaValue", value.toString())
            .putInt("quotaUnit", unit.selectedItemPosition)
            .putLong(UsageMonitorService.KEY_QUOTA_BYTES, bytes)
            .putBoolean(UsageMonitorService.KEY_AUTO_CUT, autoCut.isChecked)
            .putString("warning", warning.toString())
            .apply()
        return true
    }

    private fun startMonitoring() {
        // Request VPN consent only if the user enabled auto-cut; manual monitoring
        // alone does not need VPN permission.
        if (autoCut.isChecked) {
            requestVpnPermissionThen("monitor")
        } else {
            startMonitorService()
        }
    }

    private fun startMonitorService() {
        val intent = Intent(this, UsageMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        refresh()
        toast("Data monitoring started")
    }

    private fun requestVpnPermissionThen(action: String) {
        pendingAction = action
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(prepareIntent, vpnRequestCode)
        } else {
            runPendingAction()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != vpnRequestCode) return
        if (resultCode == RESULT_OK) runPendingAction()
        else toast("VPN permission was not granted")
    }

    private fun runPendingAction() {
        when (pendingAction) {
            "block" -> {
                val intent = Intent(this, BlockVpnService::class.java).setAction(BlockVpnService.ACTION_BLOCK)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                toast("Internet block requested")
            }
            "monitor" -> startMonitorService()
        }
        pendingAction = ""
        refresh()
    }

    private fun refresh() {
        if (!::usage.isInitialized) return
        val used = prefs.getLong(UsageMonitorService.KEY_USED, 0L)
        val quota = prefs.getLong(UsageMonitorService.KEY_QUOTA_BYTES, 20L * 1024L * 1024L * 1024L)
        val usedText = DecimalFormat("0.00").format(used / 1073741824.0)
        val quotaText = DecimalFormat("0.##").format(quota / 1073741824.0)
        usage.text = "$usedText GB used  /  $quotaText GB limit"

        val blocked = prefs.getBoolean(BlockVpnService.KEY_BLOCKED, false)
        val monitoring = prefs.getBoolean(UsageMonitorService.KEY_MONITORING, false)
        status.text = when {
            blocked -> "INTERNET BLOCKED"
            monitoring -> "MONITORING ACTIVE"
            else -> "STANDBY – MANUAL CONTROL"
        }
        status.setTextColor(if (blocked) 0xFFD92D20.toInt() else 0xFF16804A.toInt())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
