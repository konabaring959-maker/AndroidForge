# NetCap speed-limit engine status

## Implemented in this revision

- Added `SpeedLimitController.kt` as a pure Kotlin shaping primitive.
- Upload and download have independent token buckets.
- `0 B/s` means unlimited; any positive rate remains a real cap, including very low rates.
- A 100 ms burst window and adaptive relay chunk recommendation are used to avoid large bursts at low configured rates.
- Live rate changes preserve existing pacing debt instead of resetting the limiter.
- The core was compiled with `kotlinc` and passed a standalone test covering initial burst, pacing debt, very-low-rate pacing, unlimited mode, and live rate updates.

## Important: not yet connected to live traffic

This file does not capture or forward packets. The current `BlockVpnService` still acts as a packet sink while blocking internet. It must not be repurposed as a speed limiter until a real local forwarding engine is integrated.

The required production data path is:

1. Android `VpnService` captures packets in the TUN.
2. A userspace TCP/IP stack reassembles TCP/UDP flows.
3. NetCap opens protected upstream sockets using `VpnService.protect()` so they do not loop back into the TUN.
4. Upload and download bytes are paced through the matching `SpeedLimitBucket` before forwarding.
5. Quota monitoring and the existing manual block/restore actions remain separate and are regression-tested.

## Build / integration blocker

The inspected NetValve reference uses a gVisor-based userspace stack. Its documented production build requires Go 1.25+, Android NDK, JDK 17, and a generated Android AAR; its default loopback build does not forward internet traffic. This environment currently has Go 1.23 and no Android SDK/NDK or Gradle installation, so it cannot produce or validate the production APK here.

No speed-control UI has been added yet, and no claim is made that the current APK can throttle traffic. The next implementation step is integrating the real packet pipeline and protected socket relay, then wiring this tested limiter into both relay directions.
