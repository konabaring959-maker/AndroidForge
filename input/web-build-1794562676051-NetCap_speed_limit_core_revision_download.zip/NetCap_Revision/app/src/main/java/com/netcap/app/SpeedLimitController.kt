package com.netcap.app

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Thread-safe, timer-free token bucket for one traffic direction.
 *
 * A rate of 0 means unlimited. Positive rates are measured in bytes/second.
 * Unlike a packet-drop limiter, callers reserve bytes, wait for the returned
 * duration, and then forward the bytes. The small burst window and adaptive
 * chunk size are intended to keep very low configured rates usable.
 *
 * This class is the shaping primitive only. It must be called from the future
 * VPN forwarding/relay path; it does not capture or forward packets by itself.
 */
class SpeedLimitBucket(
    rateBytesPerSecond: Long,
    private val burstWindowMillis: Long = DEFAULT_BURST_WINDOW_MS,
    private val clockNanos: () -> Long = System::nanoTime,
) {
    private val lock = Any()
    private var rate = rateBytesPerSecond.coerceAtLeast(0).toDouble()
    private var capacity = capacityFor(rate)
    private var tokens = capacity
    private var lastNanos = clockNanos()

    /** Reserve [bytes] and return how many nanoseconds the caller must wait. */
    fun reserveDelayNanos(bytes: Long): Long = synchronized(lock) {
        if (bytes <= 0L || rate <= 0.0) return 0L
        refillLocked()
        tokens -= bytes.toDouble()
        if (tokens >= 0.0) return 0L
        ceil((-tokens / rate) * NANOS_PER_SECOND).toLong().coerceAtLeast(0L)
    }

    /** Apply a new rate immediately without discarding outstanding pacing debt. */
    fun updateRate(newRateBytesPerSecond: Long) = synchronized(lock) {
        refillLocked()
        rate = newRateBytesPerSecond.coerceAtLeast(0).toDouble()
        capacity = capacityFor(rate)
        if (tokens > capacity) tokens = capacity
        if (rate <= 0.0) tokens = capacity
    }

    /**
     * Keep relay writes short enough to pace smoothly. At low rates this can be
     * only a few bytes; at high rates it is capped to avoid large allocations.
     */
    fun recommendedChunkBytes(maxChunkBytes: Int = DEFAULT_MAX_CHUNK_BYTES): Int = synchronized(lock) {
        if (rate <= 0.0) return maxChunkBytes.coerceAtLeast(1)
        val bytesPerWindow = floor(rate * CHUNK_WINDOW_MILLIS / 1_000.0)
        min(maxChunkBytes.coerceAtLeast(1).toDouble(), max(1.0, bytesPerWindow)).toInt()
    }

    fun configuredRateBytesPerSecond(): Long = synchronized(lock) { rate.toLong() }

    private fun refillLocked() {
        val now = clockNanos()
        val elapsed = now - lastNanos
        if (elapsed <= 0L) return
        lastNanos = now
        if (rate <= 0.0) return
        tokens = min(capacity, tokens + elapsed.toDouble() / NANOS_PER_SECOND * rate)
    }

    private fun capacityFor(rateBytesPerSecond: Double): Double {
        if (rateBytesPerSecond <= 0.0) return 0.0
        return max(1.0, rateBytesPerSecond * burstWindowMillis / 1_000.0)
    }

    companion object {
        const val DEFAULT_BURST_WINDOW_MS = 100L
        const val CHUNK_WINDOW_MILLIS = 100L
        const val DEFAULT_MAX_CHUNK_BYTES = 16 * 1024
        private const val NANOS_PER_SECOND = 1_000_000_000.0
    }
}

/** Independent upload and download shaping controls. */
class SpeedLimitController(
    uploadBytesPerSecond: Long = 0L,
    downloadBytesPerSecond: Long = 0L,
) {
    val upload = SpeedLimitBucket(uploadBytesPerSecond)
    val download = SpeedLimitBucket(downloadBytesPerSecond)

    fun update(uploadBytesPerSecond: Long, downloadBytesPerSecond: Long) {
        upload.updateRate(uploadBytesPerSecond)
        download.updateRate(downloadBytesPerSecond)
    }
}
