# NetCap speed-limit implementation status

## Added in this revision
- Separate upload and download speed fields in the app UI.
- Units: B/s, KB/s, MB/s, with decimal entry.
- `0` means unlimited. B/s supports rates below 1 KB/s.
- Values are validated and saved as bytes/second in SharedPreferences:
  - `uploadLimitBytesPerSecond`
  - `downloadLimitBytesPerSecond`
- Thread-safe token-bucket pacing primitive in `SpeedLimitController.kt`.

## Not yet active on network traffic
The current `BlockVpnService` reads packets from the VPN TUN and discards them. It is a firewall/packet sink, not a forwarding VPN. Therefore the UI values are configuration only and do not throttle live network traffic yet. A forwarding engine must relay traffic and call the upload/download buckets before forwarding data. Do not present this revision as a working speed-throttling APK.
