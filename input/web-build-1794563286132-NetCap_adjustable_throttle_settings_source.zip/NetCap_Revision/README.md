# NetCap – Android firewall prototype

This is a native Android/Kotlin prototype for on-demand internet blocking and system-wide data monitoring.

## Features in this source
- Manual **Block Internet Now** and **Restore Internet** controls.
- Local Android `VpnService` packet sink (no remote VPN server and no root).
- Both IPv4 and IPv6 default routes are captured while the firewall is active.
- User-started foreground usage monitor.
- Editable KB/MB/GB quota.
- Separate configurable upload and download speed-limit settings (B/s, KB/s, MB/s; decimal values supported; 0 means unlimited).
- Optional quota-triggered block (off by default).
- Manual usage-counter reset.

## Important engineering limits
- This source has **not** been built or tested on a physical Android device in this environment.
- The speed-limit screen currently saves independent upload/download rates, and `SpeedLimitController` contains the token-bucket pacing primitive. The current `BlockVpnService` is still a packet sink; the speed settings are **not yet applied to live traffic** until a real VPN forwarding/relay engine is integrated.
- Android's VPN consent dialog must be approved. Only one VPN can normally be active at a time.
- This blocks routed IP traffic through the VPN interface; it does not flip the Wi-Fi or mobile-data system toggles. Some device/system traffic may behave differently.
- Usage is measured using `TrafficStats` system-wide RX + TX counters. It is not the carrier's billing meter and can differ from the telco app.
- The usage monitor accumulates deltas while its foreground service is running. If Android kills the service or the phone reboots, some usage during the gap can be missed. Reboot-safe continuous accounting and scheduled resets need a later iteration.
- Warning threshold is saved as a setting but notification delivery is not implemented in this prototype.
- Auto-cut requires VPN consent first; the app asks for consent when starting monitoring with auto-cut enabled.

## Build
1. Open the `NetCap` folder in a recent Android Studio.
2. Install Android SDK Platform 35 if prompted.
3. Sync Gradle.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the debug APK on a test Android phone.
6. Grant VPN permission when prompted.

## Test sequence
1. Install and open NetCap.
2. Tap **BLOCK INTERNET NOW** and approve VPN permission.
3. Verify a browser cannot load a new page over Wi-Fi and mobile data.
4. Tap **RESTORE INTERNET** and verify connectivity returns.
5. Start monitoring, use some traffic, and confirm the counter increases.
6. Only after manual blocking works, test quota-triggered blocking.

Do not rely on quota enforcement until tested on the target device.
