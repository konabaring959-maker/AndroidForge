# NetCap traffic forwarding integration status

## Added in this pass

`ProtectedTrafficRelay.kt` now contains the actual relay-side shaping insertion points:

- TCP upload: TUN stream read -> upload token bucket -> protected upstream TCP socket write.
- TCP download: protected upstream TCP socket read -> download token bucket -> TUN stream write.
- UDP upload/download: the same directional pacing, with a protected connected `DatagramSocket`.
- Both socket types call the `VpnService.protect(...)` adapter before connecting. A failed protect aborts the flow instead of risking a self-referential VPN loop.
- Each flow has bounded buffers and paired workers; closing either side tears down the pair.

The relay is deliberately expressed against `TunTcpFlow` / `TunUdpFlow` interfaces. The missing piece is the production packet engine adapter (gVisor netstack/gomobile) that supplies those per-flow streams and original destination IP/port. It is not safe to connect this relay to the current packet-sink `BlockVpnService` because that service currently discards packets.

## Required integration before calling throttling live

1. Add the gVisor netstack AAR and generated gomobile API to the Android app.
2. Implement adapters from generated `TCPConn` / `UDPConn` to `TunTcpFlow` / `TunUdpFlow`.
3. In the one existing `BlockVpnService`, establish the TUN once, start the packet engine, and pass `this::protect` to the relays.
4. Read `uploadLimitBytesPerSecond` and `downloadLimitBytesPerSecond` from the existing `netcap` preferences. Update the same `SpeedLimitController` on settings changes so active flows inherit new limits.
5. Keep manual block as a separate sink mode, and keep the existing quota monitor's auto-block action targeting the same service. Restore must stop the tunnel and clear `KEY_BLOCKED` exactly as before.
6. Test real IPv4/IPv6 TCP, UDP, DNS, cellular, Wi-Fi, live rate changes, auto-block and restore on a physical Android device.

## Current verification boundary

The pure Kotlin shaping and relay source can be compiled independently, but no Android VPN forwarding engine or APK has been built in this workspace. Do not ship this revision as a working throttling APK until the adapter and device tests above are complete.
