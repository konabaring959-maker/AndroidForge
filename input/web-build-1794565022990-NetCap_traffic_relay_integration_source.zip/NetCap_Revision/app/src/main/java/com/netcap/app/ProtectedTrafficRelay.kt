package com.netcap.app

import java.io.Closeable
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.LockSupport

/**
 * Byte-stream endpoint exposed by the userspace TCP/IP engine for one app-side
 * TCP flow. The eventual gVisor/gomobile adapter implements this interface.
 */
interface TunTcpFlow : Closeable {
    @Throws(IOException::class) fun read(buffer: ByteArray): Int
    @Throws(IOException::class) fun write(buffer: ByteArray, length: Int)
}

/** Datagram endpoint exposed by the userspace engine for one app-side UDP flow. */
interface TunUdpFlow : Closeable {
    @Throws(IOException::class) fun receive(): ByteArray
    @Throws(IOException::class) fun send(payload: ByteArray)
}

/** Android VpnService.protect() adapter. Must be called before connect(). */
fun interface UpstreamSocketProtector {
    fun protect(socket: java.net.Socket): Boolean
}

/** DatagramSocket has a separate overload on Android's VpnService. */
fun interface UpstreamDatagramProtector {
    fun protect(socket: DatagramSocket): Boolean
}

/**
 * Relays one TCP flow through a protected upstream socket. Upload is paced
 * before socket writes; download is paced before writes back into the TUN stack.
 * Two daemon workers are used so a blocked read in one direction cannot stall
 * the reverse direction. Closing either side tears down both workers.
 */
class ProtectedTcpRelay(
    private val limits: SpeedLimitController,
    private val socketProtector: UpstreamSocketProtector,
    private val connectTimeoutMs: Int = 15_000,
    private val maxChunkBytes: Int = 16 * 1024,
) {
    fun start(flow: TunTcpFlow, destinationIp: String, destinationPort: Int): Closeable {
        require(destinationPort in 1..65535)
        val socket = Socket()
        try {
            if (!socketProtector.protect(socket)) {
                throw IOException("VpnService.protect(Socket) failed; refusing to risk a VPN loop")
            }
            socket.tcpNoDelay = true
            socket.keepAlive = true
            socket.connect(InetSocketAddress(InetAddress.getByName(destinationIp), destinationPort), connectTimeoutMs)
        } catch (t: Throwable) {
            try { socket.close() } catch (_: Throwable) {}
            try { flow.close() } catch (_: Throwable) {}
            throw t
        }

        val closed = AtomicBoolean(false)
        fun closeBoth() {
            if (!closed.compareAndSet(false, true)) return
            try { socket.close() } catch (_: Throwable) {}
            try { flow.close() } catch (_: Throwable) {}
        }
        fun worker(name: String, body: () -> Unit) = Thread({
            try { body() } catch (_: Throwable) { /* flow teardown is expected on EOF/revoke */ }
            finally { closeBoth() }
        }, name).apply { isDaemon = true; start() }

        worker("NetCap-TCP-upload") {
            socket.getOutputStream().use { upstreamOut ->
                val buf = ByteArray(maxChunkBytes.coerceIn(256, 64 * 1024))
                while (!closed.get()) {
                    val n = flow.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    pace(limits.upload, n)
                    upstreamOut.write(buf, 0, n)
                    upstreamOut.flush()
                }
            }
        }
        worker("NetCap-TCP-download") {
            socket.getInputStream().use { upstreamIn ->
                val buf = ByteArray(maxChunkBytes.coerceIn(256, 64 * 1024))
                while (!closed.get()) {
                    val n = upstreamIn.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    pace(limits.download, n)
                    flow.write(buf, n)
                }
            }
        }
        return Closeable { closeBoth() }
    }
}

/**
 * Relays one UDP association. Datagrams are paced independently in each
 * direction. A bounded-size receive buffer prevents unbounded memory growth.
 * DNS is intentionally not exempted here: NetCap's configured cap applies
 * consistently to UDP unless a later explicit DNS policy is added.
 */
class ProtectedUdpRelay(
    private val limits: SpeedLimitController,
    private val socketProtector: UpstreamDatagramProtector,
    private val idleTimeoutMs: Int = 60_000,
    private val maxDatagramBytes: Int = 65_507,
) {
    fun start(flow: TunUdpFlow, destinationIp: String, destinationPort: Int): Closeable {
        require(destinationPort in 1..65535)
        val socket = DatagramSocket(null)
        try {
            if (!socketProtector.protect(socket)) {
                throw IOException("VpnService.protect(DatagramSocket) failed; refusing to risk a VPN loop")
            }
            socket.soTimeout = idleTimeoutMs
            socket.connect(InetAddress.getByName(destinationIp), destinationPort)
        } catch (t: Throwable) {
            try { socket.close() } catch (_: Throwable) {}
            try { flow.close() } catch (_: Throwable) {}
            throw t
        }

        val closed = AtomicBoolean(false)
        fun closeBoth() {
            if (!closed.compareAndSet(false, true)) return
            try { socket.close() } catch (_: Throwable) {}
            try { flow.close() } catch (_: Throwable) {}
        }
        fun worker(name: String, body: () -> Unit) = Thread({
            try { body() } catch (_: SocketException) { /* closed */ } catch (_: Throwable) { /* idle/teardown */ }
            finally { closeBoth() }
        }, name).apply { isDaemon = true; start() }

        worker("NetCap-UDP-upload") {
            while (!closed.get()) {
                val payload = flow.receive()
                if (payload.isEmpty()) continue
                pace(limits.upload, payload.size)
                socket.send(DatagramPacket(payload, payload.size))
            }
        }
        worker("NetCap-UDP-download") {
            val buf = ByteArray(maxDatagramBytes.coerceIn(512, 65_507))
            while (!closed.get()) {
                val packet = DatagramPacket(buf, buf.size)
                socket.receive(packet)
                val payload = packet.data.copyOfRange(packet.offset, packet.offset + packet.length)
                pace(limits.download, payload.size)
                flow.send(payload)
            }
        }
        return Closeable { closeBoth() }
    }
}

/** Paces a completed relay chunk without busy-waiting. */
internal fun pace(bucket: SpeedLimitBucket, bytes: Int) {
    var remaining = bucket.reserveDelayNanos(bytes.toLong())
    while (remaining > 0L && !Thread.currentThread().isInterrupted) {
        val before = System.nanoTime()
        LockSupport.parkNanos(remaining)
        val elapsed = (System.nanoTime() - before).coerceAtLeast(0L)
        remaining -= elapsed
    }
    if (Thread.currentThread().isInterrupted) throw InterruptedException("relay interrupted")
}
