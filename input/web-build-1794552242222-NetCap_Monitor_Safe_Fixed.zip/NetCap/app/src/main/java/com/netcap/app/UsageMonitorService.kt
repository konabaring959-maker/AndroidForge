package com.netcap.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Accumulates system-wide RX + TX byte deltas while the user-started
 * foreground monitor is running. TrafficStats is an estimate of device
 * traffic, not the carrier's billing meter.
 */
class UsageMonitorService : Service() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var previousTotal = -1L
    private var running = false

    private val sampler = object : Runnable {
        override fun run() {
            if (!running) return
            val current = totalBytes()
            if (previousTotal >= 0L && current >= previousTotal) {
                val delta = current - previousTotal
                if (delta > 0L) {
                    val used = prefs.getLong(KEY_USED, 0L) + delta
                    prefs.edit().putLong(KEY_USED, used).apply()
                    // Monitoring is deliberately passive. It must never start a VPN
                    // or alter network routing; blocking remains a separate manual action.
                }
            }
            // If the OS counter resets (e.g. reboot), establish a new baseline.
            previousTotal = current
            handler.postDelayed(this, SAMPLE_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            previousTotal = totalBytes()
            prefs.edit().putBoolean(KEY_MONITORING, true).apply()
            handler.post(sampler)
        }
        return START_STICKY
    }


    private fun totalBytes(): Long {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        return if (rx < 0L || tx < 0L) 0L else rx + tx
    }

    private fun stopMonitoring() {
        running = false
        handler.removeCallbacks(sampler)
        prefs.edit().putBoolean(KEY_MONITORING, false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(): Notification {
        val channelId = "netcap_monitor"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "NetCap data monitor", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("NetCap data monitoring")
            .setContentText("Your usage counter is being updated")
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopMonitoring()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val PREFS = "netcap"
        const val KEY_USED = "usedBytes"
        const val KEY_QUOTA_BYTES = "quotaBytes"
        const val KEY_AUTO_CUT = "auto"
        const val KEY_MONITORING = "monitoring"
        const val ACTION_STOP = "com.netcap.app.STOP_MONITOR"
        const val NOTIFICATION_ID = 201
        const val SAMPLE_INTERVAL_MS = 3000L
    }
}
