package com.netcap.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local packet sink. When enabled, all IPv4 and IPv6 default-route packets
 * are routed into this TUN interface and deliberately discarded.
 * No external VPN server is used.
 */
class BlockVpnService : VpnService() {
    private val active = AtomicBoolean(false)
    @Volatile private var tunnel: ParcelFileDescriptor? = null
    @Volatile private var readerThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UNBLOCK -> {
                stopFirewall()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_BLOCK -> startFirewall()
            null -> {
                // Never restore a traffic-blocking VPN implicitly after process recreation.
                stopFirewall()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startFirewall() {
        if (active.get()) return
        startForeground(NOTIFICATION_ID, buildNotification())

        try {
            val established = Builder()
                .setSession("NetCap firewall")
                .setMtu(1500)
                .addAddress("10.77.0.1", 32)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd77:77:77::1", 128)
                .addRoute("::", 0)
                .establish()

            if (established == null) {
                setBlocked(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }

            tunnel = established
            active.set(true)
            setBlocked(true)

            readerThread = Thread({
                // Reading packets from the TUN interface consumes and drops them.
                // Nothing is forwarded to another network interface.
                try {
                    FileInputStream(established.fileDescriptor).use { input ->
                        val packet = ByteArray(32767)
                        while (active.get()) {
                            val count = input.read(packet)
                            if (count < 0) break
                        }
                    }
                } catch (_: Exception) {
                    // Closing the descriptor during restore ends the read loop.
                } finally {
                    if (active.get()) {
                        active.set(false)
                        setBlocked(false)
                        stopSelf()
                    }
                }
            }, "NetCap-Packet-Dropper").also {
                it.isDaemon = true
                it.start()
            }
        } catch (_: Exception) {
            stopFirewall()
            stopSelf()
        }
    }

    private fun stopFirewall() {
        active.set(false)
        try { tunnel?.close() } catch (_: Exception) { }
        tunnel = null
        readerThread = null
        setBlocked(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun setBlocked(value: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_BLOCKED, value).apply()
    }

    private fun buildNotification(): Notification {
        val channelId = "netcap_firewall"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "NetCap firewall", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("NetCap: Internet blocked")
            .setContentText("Open NetCap and tap Restore Internet to reconnect")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    private fun immutableFlag(): Int =
        if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    override fun onRevoke() {
        stopFirewall()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopFirewall()
        super.onDestroy()
    }

    companion object {
        const val ACTION_BLOCK = "com.netcap.app.BLOCK"
        const val ACTION_UNBLOCK = "com.netcap.app.UNBLOCK"
        const val PREFS = "netcap"
        const val KEY_BLOCKED = "blocked"
        const val NOTIFICATION_ID = 202
    }
}
