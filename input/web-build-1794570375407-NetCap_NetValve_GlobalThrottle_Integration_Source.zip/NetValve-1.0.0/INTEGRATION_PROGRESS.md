# NetCap integration progress

This source tree contains the first NetCap-facing integration changes on top of the supplied NetValve traffic-shaping architecture.

## Changes made

- Global download and upload limit editors added to the dashboard.
- Each global limit accepts KB/s or MB/s; entering 0 clears the limit (unlimited).
- Global limits are persisted through the existing SettingsRepository/DataStore path and are consumed by the existing RuleEngine default action and ThrottleManager flow path.
- Fresh-install default routing changed to `ALL_EXCEPT` with an empty exclusion set. The VPN service already excludes its own package in this mode, so other apps are routed into the tunnel by default.
- Dashboard copy explains the all-apps default and the NetValve self-exclusion.

## Important: not an APK yet

The uploaded NetValve archive is incomplete for a production build:

1. `app/libs/netstack.aar` is absent. The production netstack source set references this AAR; the supplied Go source and build script can generate it, but the build requires Go 1.25+ and the Android NDK.
2. No `AndroidManifest.xml` is present in the uploaded archive.
3. The Gradle wrapper distribution was not cached, and this environment could not reach `services.gradle.org`, so compilation could not be run here.

Do not install a build using the default loopback source set: the project documentation explicitly says it does not forward traffic. A production build must use `-Pnetvalve.netstack=true` after the AAR and manifest/build inputs are in place.

## Remaining integration work

- Restore/add the Android manifest and app resources.
- Generate and include the gVisor netstack AAR from `netstack/build-aar.sh` using Go 1.25+ and Android NDK.
- Add NetCap mobile-data quota accounting and cutoff to the single VPN lifecycle, then test restore behaviour.
- Compile, run unit tests, and verify on a physical Android 14 device before calling it ready.
