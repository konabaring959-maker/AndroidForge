package com.netcap.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder

/**
 * Samples Android's cellular/mobile RX+TX counters only.
 * This is device-wide mobile traffic, not carrier billing usage.
 */
class UsageMonitorService : Service() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private lateinit var worker: HandlerThread
    private lateinit var handler: Handler
    @Volatile private var running = false
    private var previousMobileTotal = -1L

    private val sampler = object : Runnable {
        override fun run() {
            if (!running) return

            // Once quota blocking is active, freeze the displayed counter.
            if (prefs.getBoolean(BlockVpnService.KEY_BLOCKED, false)) {
                stopMonitoring()
                return
            }

            val current = mobileBytes()
            if (current >= 0L) {
                if (previousMobileTotal >= 0L && current >= previousMobileTotal) {
                    val delta = current - previousMobileTotal
                    if (delta > 0L) {
                        val used = prefs.getLong(KEY_USED, 0L) + delta
                        prefs.edit().putLong(KEY_USED, used).apply()
                        maybeApplyQuota(used)
                    }
                }
                previousMobileTotal = current
            }
            handler.postDelayed(this, SAMPLE_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        worker = HandlerThread("NetCap-MobileSampler").also { it.start() }
        handler = Handler(worker.looper)
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            previousMobileTotal = mobileBytes()
            prefs.edit().putBoolean(KEY_MONITORING, true).apply()
            handler.post(sampler)
        }
        return START_STICKY
    }

    private fun maybeApplyQuota(used: Long) {
        val limit = prefs.getLong(KEY_QUOTA_BYTES, 0L)
        val autoCut = prefs.getBoolean(KEY_AUTO_CUT, false)
        val alreadyBlocked = prefs.getBoolean(BlockVpnService.KEY_BLOCKED, false)
        if (autoCut && limit > 0L && used >= limit && !alreadyBlocked) {
            // Stop sampling immediately so VPN overhead cannot inflate the counter.
            running = false
            handler.removeCallbacks(sampler)
            prefs.edit().putBoolean(KEY_MONITORING, false).apply()
            val blockIntent = Intent(this, BlockVpnService::class.java)
                .setAction(BlockVpnService.ACTION_BLOCK)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(blockIntent)
            else startService(blockIntent)
        }
    }

    private fun mobileBytes(): Long {
        val rx = TrafficStats.getMobileRxBytes()
        val tx = TrafficStats.getMobileTxBytes()
        if (rx < 0L || tx < 0L) return -1L
        return rx + tx
    }

    private fun stopMonitoring() {
        running = false
        if (::handler.isInitialized) handler.removeCallbacks(sampler)
        prefs.edit().putBoolean(KEY_MONITORING, false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(): Notification {
        val channelId = "netcap_monitor"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "NetCap mobile data monitor", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("NetCap mobile data monitoring")
            .setContentText("Counting cellular/mobile data only")
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopMonitoring()
        if (::worker.isInitialized) worker.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val PREFS = "netcap"
        const val KEY_USED = "usedBytes"
        const val KEY_QUOTA_BYTES = "quotaBytes"
        const val KEY_AUTO_CUT = "auto"
        const val KEY_MONITORING = "monitoring"
        const val ACTION_STOP = "com.netcap.app.STOP_MONITOR"
        const val NOTIFICATION_ID = 201
        const val SAMPLE_INTERVAL_MS = 50L
    }
}
